<h1 align="center">
  <b> 𝙁𝙇𝘼𝙎𝙃 𝙎𝙋𝘼𝙈𝘽𝙊𝙏 </b>
</h1>
<h1 align="center">
  <b>Ꭺ ᏢϴᏔᎬᎡҒႮᏞ ՏᏢᎪᎷ ႮՏᎬᎡᏴϴͲ ᏔᎻᏆᏟᎻ ᏔϴᎡᏦ ϴΝ ͲᎬᏞᎬᏀᎡᎪᎷ ᏴᎪՏᎬᎠ ϴΝ ͲᎬᏞᎬͲᎻϴΝ. ᏴᎽ ᎠᎬᏢᏞϴᎽᏆΝᏀ/ᎻϴՏͲᏆΝᏀ ͲᎻᏆՏ Ⴎ ᏟᎪΝ ՏᏢᎪᎷ ϴΝ ͲᎬᏞᎬᏀᎡᎪᎷ ᏴᎽ ϴΝᎬ ᏟϴᎷᎷᎪΝᎠ Ͳϴ 30 ᎪᏟᏟϴႮΝͲ ᎪͲ ϴΝᎬ ͲᏆᎷᎬ.</b>
</h1>
<p align="center">
  <img src="https://te.legra.ph/file/84ba366dd4bd8fbd416de.jpg" alt="BERLIN SPAMBOT">
</p>


## Mandotry Vars 

   - `API_ID` :  Give API_ID of your Alternate Telegram Account.
   - `API_HASH` :  Give API_HASH of your Alternate Telegram Account.
   - `STRING SESSION` :  Make a string session from [here](https://replit.com/@SAJALMAURYA/Berlin-Spambot#main.py)
   - `SUDO_USERS` :  Fill Userid of yhe users whom you want to be able to control the bot. You can add multiple id by giving a space in b/w each id.


## Deployments

### Heroku

- [![Deploy](https://www.herokucdn.com/deploy/button.svg)](https://heroku.com/deploy)
- [![Deploy](https://img.shields.io/badge/DEPLOY%20VIA%20TELEGRAM%20BOT-blueviolet?style=for-the-badge&logo=telegram)](https://telegram.dog/XTZ_HerokuBot?start=c2FqYWxyb2NrL0Jlcmxpbi1TcGFtYm90IG1haW4)



### String Generator
- [![GenerateString](https://camo.githubusercontent.com/b8f040a155a621627eaf4fbc3d2bfc3201053c9184981c58a3195c6254865865/68747470733a2f2f696d672e736869656c64732e696f2f62616467652f47656e65726174652532304f6e2532305265706c2d626c756576696f6c65743f7374796c653d666f722d7468652d6261646765266c6f676f3d6170707665796f72)](https://replit.com/@SAJALMAURYA/Berlin-Spambot#main.py)
- [![GenerateString](https://img.shields.io/badge/GENRATE%20ON%20TELEGRAM-blueviolet?style=for-the-badge&logo=telegram)](https://t.me/sessiongenro_bot)
### Contact Support
Any queries or issue contact 
- [![GenerateString](https://img.shields.io/badge/DM%20ON%20TELEGRAM-blueviolet?style=for-the-badge&logo=telegram)](https://t.me/nouseridfound_bot)

## Telegram 🏪
- [![Telegram Group](https://img.shields.io/badge/Telegram-Group-brightgreen)](https://t.me/BERLINGODSPAM)
- [![Telegram Channel](https://img.shields.io/badge/Telegram-Channel-brightgreen)](https://t.me/BERLINSPAMM)

------
## CREDITS
- [TEAM YUKKI](https://github.com/notreallyshikhar)
- [LONE-WOLF](https://github.com/Lone-Wolf250)
